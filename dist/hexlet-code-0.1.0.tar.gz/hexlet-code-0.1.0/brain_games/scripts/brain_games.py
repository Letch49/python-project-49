#!/usr/bin/env python3

def main():
    print("poetry run python -m brain_games.scripts.brain_games")
    print("Welcome to the Brain Games!")


if __name__ == "__main__":
    main()
